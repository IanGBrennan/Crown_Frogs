cd /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell1.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell10.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell11.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell12.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell13.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell14.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell15.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell16.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell2.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell3.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell4.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell5.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell6.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell7.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell8.sh &
source /Users/ianbrennan/Documents/GitHub/Crown_Frogs/Myobatrachidae/Original_Alignments/MACSE_Shells/MACSE_Shell9.sh &
exit 0
